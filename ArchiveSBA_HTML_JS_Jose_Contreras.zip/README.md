InvestPulse -Tracker Website
Welcome to the InvestPulse website repository.
This website is composed of HTML, JS, and CSS and is currently made up of four pages.
The first page is the Home and Index page shows a welcome and quick description of the website which is to create an account to track specific stocks, bonds, or cryptocurrencies. The user can also sign up by entering their first and last name along with their email and have the option on the drop-down menu to select the style of account they want. Two images were used. There is also a navigation button to allow for the navigation between the pages.

The navigation page keeps the same format with the logo, navigation buttons, and title of the page but this shows the user’s crypto and stock list with the ticker symbols they selected along with the purchased price, current price, and change of price % these are separated by two pages portfolio, and portfolio 2. This page has a different color background and a copywrite footer.

The last page is the contact page. It has the company email and phone number information as well as links to the social media platforms. Lastly, the user can contact the company by entering their name, and email entering a message then clicking on the send button.

Technologies used include HTML which was used to structure all three pages titled Home, Portfolio and Contact.
CSS was used to styling this page which included both inline, internal, and external CSS to add background color, images, GIFs, videos, font types and sizes.
JavaScript allowed for interactivity to be added to the web pages which included the external script for event handling.
